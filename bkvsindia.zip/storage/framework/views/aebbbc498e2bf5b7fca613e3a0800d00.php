
<?php $__env->startSection('title'); ?>
Admission Create - BKVS INDIA
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="container-fluid">
   <div class="row">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-body">
               <div class="row">
                  <div class="col-lg-12 order-lg-1">
                     <h3 class="mb-3">Admission Create</h3>
                     <form action="<?php echo e(isset($admissions) ? route('admin.admission.update', $admissions->id) : route('admin.admission.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($admissions)): ?>
                        <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <div class="row">
                           <!-- Center and Course -->
                           <h4 style="color: #EC6923;" class="mb-3 mt-3">
                              <i class="bi bi-person-fill" style="color: #EC6923;"></i> Student Details
                           </h4>
                           <hr>
                           <div class="col-md-4 mb-3">
                              <label for="center_id" class="form-label">Center</label>
                              <select class="form-control" name="center_id" id="center_id">
                                 <option value="" selected disabled>Choose a center</option>
                                 <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($center->id); ?>"
                                    <?php echo e(old('center_id', $admissions->center_id ?? '') == $center->id ? 'selected' : ''); ?>>
                                    <?php echo e($center->center_code); ?> - (<?php echo e($center->institute_name); ?>)
                                 </option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                              <?php $__errorArgs = ['center_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <!-- Student Details -->
                           <div class="col-md-4 mb-3">
                              <label for="student_name" class="form-label">Student Name</label>
                              <input type="text" class="form-control" name="student_name" id="student_name"
                                 value="<?php echo e(old('student_name', $admissions->student_name ?? '')); ?>">
                              <?php $__errorArgs = ['student_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>




                           <div class="col-md-4">
                              <div class="form-grp">
                                 <label for="course-category">Course Category *</label>
                                 <select name="course_id" id="course-category" class="form-select form-control" required>
                                    <option value="">Choose Category</option>
                                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($course->id); ?>" <?php echo e(isset($admissions) && $admissions->course_id == $course->id ? 'selected' : ''); ?>>
                                       <?php echo e($course->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-grp">
                                 <label for="subcourse">Select Courses *</label>
                                 <select name="subcourse_id" id="subcourse" class="form-select form-control" required>
                                    <option value="">Choose Courses</option>
                                    <?php if(isset($subcourses) && $subcourses->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $subcourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcourse->id); ?>" <?php echo e(isset($admissions) && $admissions->subcourse_id == $subcourse->id ? 'selected' : ''); ?>>
                                       <?php echo e($subcourse->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                 </select>
                              </div>
                           </div>


                           <div class="col-md-4 mb-3">
                              <label for="gender" class="form-label">Gender</label>
                              <select class="form-control" name="gender" id="gender">
                                 <option value="" selected disabled>Choose a Gender</option>
                                 <option value="male" <?php echo e(old('gender', $admissions->gender ?? '') == 'male' ? 'selected' : ''); ?>>Male</option>
                                 <option value="female" <?php echo e(old('gender', $admissions->gender ?? '') == 'female' ? 'selected' : ''); ?>>Female</option>
                              </select>
                              <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <!-- Additional Student Information -->
                           <div class="col-md-4 mb-3">
                              <label for="dob" class="form-label">Date of Birth</label>
                              <input type="date" class="form-control" name="dob" id="dob" value="<?php echo e(old('dob', $admissions->dob ?? '')); ?>">
                              <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="registration_date" class="form-label">Registration Date</label>
                              <input type="date" class="form-control" name="registration_date" id="registration_date"
                                 value="<?php echo e(old('registration_date', $admissions->registration_date ?? '')); ?>">
                              <?php $__errorArgs = ['registration_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <!-- Enrollment and Roll Numbers -->
                           <div class="col-md-4 mb-3">
                              <label for="roll_no" class="form-label">Roll Number</label>
                              <input type="text" class="form-control" name="roll_no" id="roll_no"
                                 value="<?php echo e(old('roll_no', $admissions->roll_no ?? '')); ?>" readonly>
                              <?php $__errorArgs = ['roll_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              <small class="form-text text-muted">Roll Number is automatically generated based on session & course program.</small>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="enroll_no" class="form-label">Enrollment Number</label>
                              <input type="text" class="form-control" name="enroll_no" id="enroll_no"
                                 value="<?php echo e(old('enroll_no', $admissions->enroll_no ?? '')); ?>" readonly>
                              <?php $__errorArgs = ['enroll_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              <small class="form-text text-muted">Enrollment Number is automatically generated based on session & course program.</small>
                           </div>

                           <div class="col-md-4 mb-3">
                              <label for="mobile_no" class="form-label">Mobile No</label>
                              <input type="number" class="form-control" name="mobile_no" id="mobile_no"
                                 value="<?php echo e(old('mobile_no', $admissions->mobile_no ?? '')); ?>">
                              <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="alternate_contact_no" class="form-label">Alternate Contact No</label>
                              <input type="number" class="form-control" name="alternate_contact_no" id="alternate_contact_no"
                                 value="<?php echo e(old('alternate_contact_no', $admissions->alternate_contact_no ?? '')); ?>">
                              <?php $__errorArgs = ['alternate_contact_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="email" class="form-label">Email</label>
                              <input type="email" class="form-control" name="email" id="email"
                                 value="<?php echo e(old('email', $admissions->email ?? '')); ?>">
                              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="semester" class="form-label">Semester</label>
                              <input type="text" class="form-control" name="semester" id="semester"
                                 value="<?php echo e(old('semester', $admissions->semester ?? '')); ?>">
                              <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="registration_year" class="form-label">Registration Year</label>
                              <select class="form-control" name="registration_year" id="registration_year">
                                 <option value="">Choose Year</option>
                                 <?php
                                 $currentYear = date('Y');
                                 ?>
                                 <?php for($year = $currentYear; $year >= 1950; $year--): ?>
                                 <option value="<?php echo e($year); ?>" <?php echo e(old('registration_year', $admissions->registration_year ?? '') == $year ? 'selected' : ''); ?>>
                                    <?php echo e($year); ?>

                                 </option>
                                 <?php endfor; ?>
                              </select>
                              <?php $__errorArgs = ['registration_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <!-- Education Details -->
                           <div class="col-md-4 mb-3">
                              <label for="tenth_passing_year" class="form-label">10th Passing Year</label>
                              <select class="form-control" name="tenth_passing_year" id="tenth_passing_year">
                                 <option value="">Choose Year</option>
                                 <?php for($year = $currentYear; $year >= 1950; $year--): ?>
                                 <option value="<?php echo e($year); ?>" <?php echo e(old('tenth_passing_year', $admissions->tenth_passing_year ?? '') == $year ? 'selected' : ''); ?>>
                                    <?php echo e($year); ?>

                                 </option>
                                 <?php endfor; ?>
                              </select>
                              <?php $__errorArgs = ['tenth_passing_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="twelfth_passing_year" class="form-label">12th Passing Year</label>
                              <select class="form-control" name="twelfth_passing_year" id="twelfth_passing_year">
                                 <option value="">Choose Year</option>
                                 <?php for($year = $currentYear; $year >= 1950; $year--): ?>
                                 <option value="<?php echo e($year); ?>" <?php echo e(old('twelfth_passing_year', $admissions->twelfth_passing_year ?? '') == $year ? 'selected' : ''); ?>>
                                    <?php echo e($year); ?>

                                 </option>
                                 <?php endfor; ?>
                              </select>
                              <?php $__errorArgs = ['twelfth_passing_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <!-- Contact Information -->
                           <!-- Address -->
                           <div class="col-md-4 mb-3">
                              <label for="state" class="form-label">State</label>
                              <select class="form-control" name="state" id="state">
                                 <option value="">Choose State</option>
                                 <?php $__currentLoopData = config('settings.states'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($state); ?>" <?php echo e(old('state', $admissions->state ?? '') == $state ? 'selected' : ''); ?>>
                                    <?php echo e($state); ?>

                                 </option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                              <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="city" class="form-label">City</label>
                              <input type="text" class="form-control" name="city" id="city"
                                 value="<?php echo e(old('city', $admissions->city ?? '')); ?>">
                              <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>

                           <div class="col-md-4 mb-3">
                              <label for="remarks" class="form-label">Remarks</label>
                              <textarea class="form-control" name="remarks" id="remarks"><?php echo e(old('remarks', $admissions->remarks ?? '')); ?></textarea>
                              <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>


                           <!-- Course Program Selection -->

                           <div class="col-md-12">
                              <label for="course_program" class="form-label">Course Program</label>
                              <select class="form-control" name="course_program" id="course_program">
                                 <option value="">Choose Program</option>
                                 <option value="one_year" <?php echo e(old('course_program', $admissions->course_program ?? '') == 'one_year' ? 'selected' : ''); ?>>One Year</option>
                                 <option value="two_year" <?php echo e(old('course_program', $admissions->course_program ?? '') == 'two_year' ? 'selected' : ''); ?>>Two Year</option>
                              </select>
                              <?php $__errorArgs = ['course_program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>


                           <!-- Sessions for One Year -->

                           <div class="col-md-12 mt-3" id="oneYearSession" style="display: none;">
                              <table class="table table-bordered">
                                 <thead>
                                    <tr>
                                       <th>Start Session</th>
                                       <th>End Session</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td>
                                          <select class="form-control" name="start_session" id="start_session">
                                             <option value="">Choose Year</option>
                                             <?php $currentYear = date('Y'); ?>
                                             <?php for($year = $currentYear; $year >= 1950; $year--): ?>
                                             <option value="<?php echo e($year); ?>" <?php echo e(old('start_session', $admissions->start_session ?? '') == $year ? 'selected' : ''); ?>><?php echo e($year); ?></option>
                                             <?php endfor; ?>
                                          </select>
                                       </td>
                                       <td>
                                          <select class="form-control" name="end_session" id="end_session">
                                             <option value="">Choose Year</option>
                                             <?php for($year = $currentYear; $year >= 1950; $year--): ?>
                                             <option value="<?php echo e($year); ?>" <?php echo e(old('end_session', $admissions->end_session ?? '') == $year ? 'selected' : ''); ?>><?php echo e($year); ?></option>
                                             <?php endfor; ?>
                                          </select>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>


                           <!-- Sessions for Two Years -->

                           <div class="col-md-12  mt-3" id="twoYearSession" style="display: none;">
                              <table class="table table-bordered">
                                 <thead>
                                    <tr>
                                       <th>1st Year Start</th>
                                       <th>1st Year End</th>
                                       <th>2nd Year Start</th>
                                       <th>2nd Year End</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td>
                                          <select class="form-control" name="start_session_first" id="start_session_first">
                                             <option value="">Choose Year</option>
                                             <?php for($year = $currentYear; $year >= 1950; $year--): ?>
                                             <option value="<?php echo e($year); ?>" <?php echo e(old('start_session_first', $admissions->start_session_first ?? '') == $year ? 'selected' : ''); ?>><?php echo e($year); ?></option>
                                             <?php endfor; ?>
                                          </select>
                                       </td>
                                       <td>
                                          <select class="form-control" name="end_session_first" id="end_session_first">
                                             <option value="">Choose Year</option>
                                             <?php for($year = $currentYear; $year >= 1950; $year--): ?>
                                             <option value="<?php echo e($year); ?>" <?php echo e(old('end_session_first', $admissions->end_session_first ?? '') == $year ? 'selected' : ''); ?>><?php echo e($year); ?></option>
                                             <?php endfor; ?>
                                          </select>
                                       </td>
                                       <td>
                                          <select class="form-control" name="start_session_second" id="start_session_second">
                                             <option value="">Choose Year</option>
                                             <?php for($year = $currentYear; $year >= 1950; $year--): ?>
                                             <option value="<?php echo e($year); ?>" <?php echo e(old('start_session_second', $admissions->start_session_second ?? '') == $year ? 'selected' : ''); ?>><?php echo e($year); ?></option>
                                             <?php endfor; ?>
                                          </select>
                                       </td>
                                       <td>
                                          <select class="form-control" name="end_session_second" id="end_session_second">
                                             <option value="">Choose Year</option>
                                             <?php for($year = $currentYear; $year >= 1950; $year--): ?>
                                             <option value="<?php echo e($year); ?>" <?php echo e(old('end_session_second', $admissions->end_session_second ?? '') == $year ? 'selected' : ''); ?>><?php echo e($year); ?></option>
                                             <?php endfor; ?>
                                          </select>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>



                           <h4 style="color: #EC6923;" class="mb-3 mt-3">
                              <i class="bi bi-journal-bookmark" style="color: #EC6923;"></i> Academic Details
                           </h4>
                           <hr>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">10th Year</label>
                              <input type="number" class="form-control" name="year_10th" id="year_10th"
                                 value="<?php echo e(old('year_10th', $admissions->year_10th ?? '')); ?>">
                              <?php $__errorArgs = ['year_10th'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">Stream</label>
                              <input type="text" class="form-control" name="stream_10th" id="stream_10th"
                                 value="<?php echo e(old('stream_10th', $admissions->stream_10th ?? '')); ?>">
                              <?php $__errorArgs = ['stream_10th'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">Board / university</label>
                              <input type="text" class="form-control" name="board_university_10th" id="board_university_10th"
                                 value="<?php echo e(old('board_university_10th', $admissions->board_university_10th ?? '')); ?>">
                              <?php $__errorArgs = ['board_university_10th'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">Result</label>
                              <input type="number" class="form-control" name="result_10th" id="result_10th"
                                 value="<?php echo e(old('result_10th', $admissions->result_10th ?? '')); ?>">
                              <?php $__errorArgs = ['result_10th'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">12th Year</label>
                              <input type="number" class="form-control" name="year_12th" id="year_12th"
                                 value="<?php echo e(old('year_12th', $admissions->year_12th ?? '')); ?>">
                              <?php $__errorArgs = ['year_12th'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">Stream</label>
                              <input type="text" class="form-control" name="stream_12th" id="stream_12th"
                                 value="<?php echo e(old('stream_12th', $admissions->stream_12th ?? '')); ?>">
                              <?php $__errorArgs = ['stream_12th'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">Board / university</label>
                              <input type="text" class="form-control" name="board_university_12th" id="board_university_12th"
                                 value="<?php echo e(old('board_university_12th', $admissions->board_university_12th ?? '')); ?>">
                              <?php $__errorArgs = ['board_university_12th'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">Result</label>
                              <input type="number" class="form-control" name="result_12th" id="result_12th"
                                 value="<?php echo e(old('result_12th', $admissions->result_12th ?? '')); ?>">
                              <?php $__errorArgs = ['result_12th'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">Other</label>
                              <input type="number" class="form-control" name="other_year" id="other_year"
                                 value="<?php echo e(old('other_year', $admissions->other_year ?? '')); ?>">
                              <?php $__errorArgs = ['other_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">Stream</label>
                              <input type="text" class="form-control" name="other_stream" id="other_stream"
                                 value="<?php echo e(old('other_stream', $admissions->other_stream ?? '')); ?>">
                              <?php $__errorArgs = ['other_stream'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">Board / university</label>
                              <input type="text" class="form-control" name="other_board_university" id="other_board_university"
                                 value="<?php echo e(old('other_board_university', $admissions->other_board_university ?? '')); ?>">
                              <?php $__errorArgs = ['other_board_university'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-3 mb-3">
                              <label for="academic_year" class="form-label">Result</label>
                              <input type="number" class="form-control" name="other_result" id="other_result"
                                 value="<?php echo e(old('other_result', $admissions->other_result ?? '')); ?>">
                              <?php $__errorArgs = ['other_result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <h4 style="color: #EC6923;" class="mb-3 mt-3">
                              <i class="bi bi-person-circle" style="color: #EC6923;"></i> Parents Details
                           </h4>
                           <hr>
                           <div class="col-md-6 mb-3">
                              <label for="father_name" class="form-label">Father's Name</label>
                              <input type="text" class="form-control" name="father_name" id="father_name"
                                 value="<?php echo e(old('father_name', $admissions->father_name ?? '')); ?>">
                              <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-6 mb-3">
                              <label for="mother_name" class="form-label">Mother's Name</label>
                              <input type="text" class="form-control" name="mother_name" id="mother_name"
                                 value="<?php echo e(old('mother_name', $admissions->mother_name ?? '')); ?>">
                              <?php $__errorArgs = ['mother_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <!-- Educational Documents -->
                           <h4 style="color: #EC6923;" class="mb-3 mt-3">
                              <i class="bi bi-upload" style="color: #EC6923;"></i> Documents
                           </h4>
                           <hr>
                           <div class="col-md-4 mb-3">
                              <label for="photo" class="form-label">Photo</label>
                              <input type="file" name="photo" multiple id="input-file-max-fs1"
                                 class="dropify dropify-event"
                                 data-allowed-file-extensions="png jpg jpeg" data-max-file-size="2M"
                                 data-default-file="<?php echo e(@asset($admissions->photo)); ?>" />
                              <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>

                           <div class="col-md-4 mb-3">
                              <label for="signature" class="form-label">10th</label>
                              <input type="file" name="tenth_image" multiple id="input-file-max-fs1"
                                 class="dropify dropify-event"
                                 data-allowed-file-extensions="png jpg jpeg" data-max-file-size="2M"
                                 data-default-file="<?php echo e(@asset($admissions->tenth_image)); ?>" />
                              <?php $__errorArgs = ['tenth_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="photo" class="form-label">12th</label>
                              <input type="file" name="twelfth_image" multiple id="input-file-max-fs1"
                                 class="dropify dropify-event"
                                 data-allowed-file-extensions="png jpg jpeg" data-max-file-size="2M"
                                 data-default-file="<?php echo e(@asset($admissions->twelfth_image)); ?>" />
                              <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="signature" class="form-label">Graduation</label>
                              <input type="file" name="graduation_image" multiple id="input-file-max-fs1"
                                 class="dropify dropify-event"
                                 data-allowed-file-extensions="png jpg jpeg" data-max-file-size="2M"
                                 data-default-file="<?php echo e(@asset($admissions->graduation_image)); ?>" />
                              <?php $__errorArgs = ['signature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="signature" class="form-label">Post Graduation</label>
                              <input type="file" name="post_graduation_image" multiple id="input-file-max-fs1"
                                 class="dropify dropify-event"
                                 data-allowed-file-extensions="png jpg jpeg" data-max-file-size="2M"
                                 data-default-file="<?php echo e(@asset($admissions->post_graduation_image)); ?>" />
                              <?php $__errorArgs = ['signature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="signature" class="form-label">ID Proof</label>
                              <input type="file" name="id_proof" multiple id="input-file-max-fs1"
                                 class="dropify dropify-event"
                                 data-allowed-file-extensions="png jpg jpeg" data-max-file-size="2M"
                                 data-default-file="<?php echo e(@asset($admissions->id_proof)); ?>" />
                              <?php $__errorArgs = ['signature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-md-4 mb-3">
                              <label for="signature" class="form-label">Other Document</label>
                              <input type="file" name="other_document" multiple id="input-file-max-fs1"
                                 class="dropify dropify-event"
                                 data-allowed-file-extensions="png jpg jpeg" data-max-file-size="2M"
                                 data-default-file="<?php echo e(@asset($admissions->other_document)); ?>" />
                              <?php $__errorArgs = ['other_document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="text-end">
                              <button type="button" class="btn btn-secondary mx-2">
                                 <i class="fas fa-times-circle"></i> Cancel
                              </button>
                              <button type="submit" class="btn btn-danger">
                                 <i class="fas fa-save"></i> <?php echo e(isset($admissions) ? 'Update' : 'Submit'); ?>

                              </button>
                           </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<!-- JavaScript -->
<script>
   document.addEventListener('DOMContentLoaded', () => {
      const courseProgram = document.getElementById('course_program');
      const oneYearSession = document.getElementById('oneYearSession');
      const twoYearSession = document.getElementById('twoYearSession');

      const toggleSessions = () => {
         const selectedProgram = courseProgram.value;
         oneYearSession.style.display = selectedProgram === 'one_year' ? 'block' : 'none';
         twoYearSession.style.display = selectedProgram === 'two_year' ? 'block' : 'none';
      };

      toggleSessions();
      courseProgram.addEventListener('change', toggleSessions);
   });
</script>

<script>
   $(document).ready(function() {
      // Load subcourses dynamically when course changes
      $('#course-category').on('change', function() {
         var courseId = $(this).val();

         if (courseId) {
            $.ajax({
               url: "<?php echo e(route('get.subcourses')); ?>",
               type: "POST",
               data: {
                  _token: "<?php echo e(csrf_token()); ?>",
                  course_id: courseId
               },
               success: function(response) {
                  $('#subcourse').empty().append('<option value="">Choose Courses</option>');
                  $.each(response, function(key, subcourse) {
                     $('#subcourse').append('<option value="' + subcourse.id + '">' + subcourse.name + '</option>');
                  });

                  // Pre-select the subcourse in edit mode
                  var selectedSubcourse = "<?php echo e(isset($admissions) ? $admissions->subcourse_id : ''); ?>";
                  if (selectedSubcourse) {
                     $('#subcourse').val(selectedSubcourse);
                  }
               },
               error: function(xhr) {
                  console.error(xhr.responseText);
               }
            });
         } else {
            $('#subcourse').empty().append('<option value="">Choose Courses</option>');
         }
      });

      // Automatically trigger subcourse load in edit mode
      var selectedCourse = "<?php echo e(isset($admissions) ? $admissions->course_id : ''); ?>";
      if (selectedCourse) {
         $('#course-category').trigger('change');
      }
   });
</script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bkvsindia\resources\views/admin/admissions/create.blade.php ENDPATH**/ ?>