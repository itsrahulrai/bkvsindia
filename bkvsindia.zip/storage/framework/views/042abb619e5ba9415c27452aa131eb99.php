<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="BKVS - Online Courses & Education Template">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="site-url" content="<?php echo e(url('/')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <?php echo $__env->make('front.inc.head-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    


</head>

<body>

    

    <?php echo $__env->make('front.inc.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    

    <?php echo $__env->make('front.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    


    <?php echo $__env->yieldContent('content'); ?>

    

    <?php echo $__env->make('front.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    

    <?php echo $__env->make('front.inc.footer-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Toastr JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<script>
    <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>", "Success", {
            "closeButton": true,
            "progressBar": true,
            "timeOut": 5000, // 5 seconds
            "positionClass": "toast-top-right"
        });
    <?php endif; ?>

    <?php if(session('error')): ?>
        toastr.error("<?php echo e(session('error')); ?>", "Error", {
            "closeButton": true,
            "progressBar": true,
            "timeOut": 5000, // 5 seconds
            "positionClass": "toast-top-right"
        });
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error("<?php echo e($error); ?>", "Validation Error", {
                "closeButton": true,
                "progressBar": true,
                "timeOut": 5000, // 5 seconds
                "positionClass": "toast-top-right"
            });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</script>
    
    <?php echo $__env->yieldPushContent('script'); ?>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\bkvsindia\resources\views/front/layout/master.blade.php ENDPATH**/ ?>