    <!--Preloader-->
    <div id="preloader">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="<?php echo e(asset('front-assets/img/logo/favicon.ico')); ?>" alt="Preloader"></div>
            </div>
        </div>
    </div>
    <!--Preloader-end -->
<?php /**PATH C:\xampp\htdocs\bkvsindia\resources\views/front/inc/loader.blade.php ENDPATH**/ ?>