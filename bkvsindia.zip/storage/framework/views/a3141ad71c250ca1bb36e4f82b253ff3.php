<?php $__env->startSection('title', 'Center Zone Login'); ?>
<?php $__env->startSection('content'); ?>


    <main class="main-area fix">

        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg"
            data-background="<?php echo e(asset('front-assets/img/bg/breadcrumb_bg.jpg')); ?>">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb__content">
                            <h3 class="title">Center Zone Login</h3>
                            <nav class="breadcrumb">
                                <span property="itemListElement" typeof="ListItem">
                                    <a href="<?php echo e(url('/')); ?>">Home</a>
                                </span>
                                <span class="breadcrumb-separator"><i class="fas fa-angle-right"></i></span>
                                <span property="itemListElement" typeof="ListItem">Center Zone Login</span>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb__shape-wrap">
                <img src="<?php echo e(asset('front-assets/img/others/breadcrumb_shape01.svg')); ?>" alt="img"
                    class="alltuchtopdown">
                <img src="<?php echo e(asset('front-assets/img/others/breadcrumb_shape02.svg')); ?>" alt="img"
                    data-aos="fade-right" data-aos-delay="300">
                <img src="<?php echo e(asset('front-assets/img/others/breadcrumb_shape03.svg')); ?>" alt="img" data-aos="fade-up"
                    data-aos-delay="400">
                <img src="<?php echo e(asset('front-assets/img/others/breadcrumb_shape04.svg')); ?>" alt="img"
                    data-aos="fade-down-left" data-aos-delay="400">
                <img src="<?php echo e(asset('front-assets/img/others/breadcrumb_shape05.svg')); ?>" alt="img" data-aos="fade-left"
                    data-aos-delay="400">
            </div>
        </section>
        <!-- breadcrumb-area-end -->

        <!-- singUp-area -->
        <section class="singUp-area section-py-120">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="singUp-wrap">
                            <h2 class="title text-center">Center Zone Login</h2>
                            <form method="POST" action="<?php echo e(route('login')); ?>" class="account__form">
                                <?php echo csrf_field(); ?>
                                <div class="form-grp">
                                    <label for="email">Email</label>
                                    <input id="email" class="input100" type="text" name="email"
                                        value="<?php echo e(old('email')); ?>" placeholder="Email">
                                    <?php if($errors->has('email')): ?>
                                        <code class="text-danger"><?php echo e($errors->first('email')); ?></code>
                                    <?php endif; ?>
                                </div>
                                <div class="form-grp">
                                    <label for="password">Password</label>
                                    <input id="password" class="input100" type="password" name="password"
                                        placeholder="Password">
                                    <?php if($errors->has('password')): ?>
                                        <code class="text-danger"><?php echo e($errors->first('password')); ?></code>
                                    <?php endif; ?>
                                </div>
                                <button type="submit" class="btn btn-two arrow-btn">
                                    Sign In
                                    <img src="<?php echo e(asset('front-assets/img/icons/right_arrow.svg')); ?>" alt="img"
                                        class="injectable">
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- singUp-area-end -->


    </main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bkvsindia\resources\views/front/center-login.blade.php ENDPATH**/ ?>