<link rel="shortcut icon" type="image/x-icon" href="{{ asset('front-assets/img/logo/favicon.ico') }}">
<!-- Place favicon.ico in the root directory -->

<!-- CSS here -->
<link rel="stylesheet" href="{{ asset('front-assets/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/animate.min.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/magnific-popup.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/fontawesome-all.min.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/flaticon-skillgro.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/flaticon-skillgro-new.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/swiper-bundle.min.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/default-icons.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/select2.min.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/odometer.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/aos.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/plyr.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/spacing.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/tg-cursor.css') }}">
<link rel="stylesheet" href="{{ asset('front-assets/css/main.css') }}">
<!-- Toastr CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
