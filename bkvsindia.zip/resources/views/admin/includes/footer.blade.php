<div class="footer">
		
        <div class="copyright">
        <p>Copyright © BKVS INDIA | Designed &amp; Developed by <a href="https://hoverbusinessservices.com/" target="_blank">Hover Business Services LLP</a> <?php date('Y') ?></p>
        </div>
    </div>