<?php $__env->startSection('title', 'Disclaimer Center - Bhartiya Kaushal Vikas Sansthan'); ?>
<?php $__env->startSection('content'); ?>

    <!-- main-area -->

    <main class="main-area fix">

        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg"
            data-background="<?php echo e(asset('front-assets/img/bg/breadcrumb_bg.jpg')); ?>">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb__content">
                            <h3 class="title">Disclaimer Center  </h3>
                            <nav class="breadcrumb">
                                <span property="itemListElement" typeof="ListItem">
                                    <a href="<?php echo e(url('/')); ?>">Home</a>
                                </span>
                                <span class="breadcrumb-separator"><i class="fas fa-angle-right"></i></span>
                                <span property="itemListElement" typeof="ListItem">Disclaimer Center </span>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb__shape-wrap">
                <img src="<?php echo e(asset('front-assets/img/others/breadcrumb_shape01.svg')); ?>" alt="img"
                    class="alltuchtopdown">
                <img src="<?php echo e(asset('front-assets/img/others/breadcrumb_shape02.svg')); ?>" alt="img"
                    data-aos="fade-right" data-aos-delay="300">
                <img src="<?php echo e(asset('front-assets/img/others/breadcrumb_shape03.svg')); ?>" alt="img" data-aos="fade-up"
                    data-aos-delay="400">
                <img src="<?php echo e(asset('front-assets/img/others/breadcrumb_shape04.svg')); ?>" alt="img"
                    data-aos="fade-down-left" data-aos-delay="400">
                <img src="<?php echo e(asset('front-assets/img/others/breadcrumb_shape05.svg')); ?>" alt="img" data-aos="fade-left"
                    data-aos-delay="400">
            </div>
        </section>
        <!-- breadcrumb-area-end -->

        <!-- about-area -->
        <section class="about-area-three section-py-120">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-lg-6">
                        <div class="section__title mb-10">
                            <h2 class="title"> Disclaimer Center </h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about-area-end -->


    </main>

    <!-- main-area --->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bkvsindia\resources\views/front/about/disclaimer-center.blade.php ENDPATH**/ ?>