    <!--Preloader-->
    <div id="preloader">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="{{asset('front-assets/img/logo/favicon.ico')}}" alt="Preloader"></div>
            </div>
        </div>
    </div>
    <!--Preloader-end -->
