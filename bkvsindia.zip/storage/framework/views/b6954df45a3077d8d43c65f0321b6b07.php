
<?php $__env->startSection('title'); ?>
Centers
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="card-title">Centers</h4>
                    <a href="<?php echo e(route('admin.center.create')); ?>" class="btn btn-rounded btn-danger"><span
                            class="btn-icon-start text-info"><i class="fa fa-plus color-danger"></i>
                        </span>Add</a>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example3" class="display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>SI.NO</th>
                                    <th>Center Code</th>
                                    <th>Institute Name</th>
                                    <th>Director</th>
                                    <th>Certificate</th>
                                    <th>Mobile No</th>
                                    <th>Address</th>
                                    <th>State</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($center->center_code); ?></td>
                                    <td><?php echo e($center->institute_name); ?></td>
                                    <td><?php echo e($center->director); ?></td>
                                    <td><?php echo e($center->certificate); ?></td>
                                    <td><?php echo e($center->mobile); ?></td>
                                    <td><?php echo e($center->address); ?></td>
                                    <td><?php echo e($center->state); ?></td>
                                    <td><?php echo e($center->date); ?></td>
                                    <td>
                                        <div class="mb-3 col-md-12">
                                            <select id="inputState" class="default-select form-control wide change-status" name="status" data-id="<?php echo e($center->id); ?>">
                                                <option value="pending" <?php echo e(old('status', $center->status ?? 'pending') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                                                <option value="active" <?php echo e(old('status', $center->status ?? 'pending') === 'active' ? 'selected' : ''); ?>>Active</option>
                                                <option value="inactive" <?php echo e(old('status', $center->status ?? 'pending') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                            </select>
                                        </div>
                                    </td>


                                    <td>
                                        <div class="d-flex">
                                            <!-- Edit Button -->
                                            <a href="<?php echo e(route('admin.center.edit', $center->id )); ?>" class="btn btn-primary shadow btn-sm me-2" title="Edit Course">
                                                <i class="fas fa-edit fs-7"></i>
                                            </a>
                                            <!-- Delete Button -->
                                            <a href="<?php echo e(route('admin.center.destroy', $center->id )); ?>" class="btn btn-danger shadow btn-sm delete-item" title="Delete Course">
                                                <i class="fas fa-trash-alt fs-7"></i>
                                            </a>
                                            </form>
                                        </div>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function() {
        $('body').on('change', '.change-status', function() {
            let selectedStatus = $(this).val();
            let id = $(this).data('id');
            $.ajax({
                url: "<?php echo e(route('admin.center.change-status')); ?>",
                method: 'PUT',
                data: {
                    status: selectedStatus,
                    id: id
                },
                success: () => Swal.fire('Success', 'Status has been updated!', 'success'),
                error: () => Swal.fire('Error', 'Failed to update status.', 'error')
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bkvsindia\resources\views/admin/centers/apply-franchise.blade.php ENDPATH**/ ?>