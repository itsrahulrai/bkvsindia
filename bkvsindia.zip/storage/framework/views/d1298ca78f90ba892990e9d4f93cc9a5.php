
<?php $__env->startSection('title'); ?>
Centers
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h4 class="card-title">Centers</h4>
          <!-- <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> New
          </a> -->
          <a href="<?php echo e(route('admin.center.create')); ?>"  class="btn btn-rounded btn-danger"><span
                                        class="btn-icon-start text-info"><i class="fa fa-plus color-danger"></i>
                                    </span>Add</a>
        </div>

        <div class="card-body">
          <div class="table-responsive">
            <table id="example3" class="display" style="min-width: 845px">
              <thead>
                <tr>
                  <th>SI.NO</th>
                  <th>Center Code</th>
                  <th>Institute Name</th>
                  <th>Director</th>
                  <th>Mobile No</th>
                  <th>Address</th>
                  <th>State</th>
                  <th>Area</th>
                  <th>Password</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($key + 1); ?></td>
                  <td><?php echo e($center->center_code); ?></td>
                  <td><?php echo e($center->institute_name); ?></td>
                  <td><?php echo e($center->director); ?></td>
                  <td><?php echo e($center->mobile); ?></td>
                  <td><?php echo e($center->address); ?></td>
                  <td><?php echo e($center->state); ?></td>
                  <td><?php echo e($center->centre_area); ?></td>
                  <td><?php echo e($center->password); ?></td>
                  <td><?php echo e($center->date); ?></td>
                  <td><?php echo e($center->status); ?></td>
                  <td>
                    <div class="d-flex">
                      <!-- Edit Button -->
                      <a href="<?php echo e(route('admin.center.edit', $center->id )); ?>" class="btn btn-primary shadow btn-sm me-2" title="Edit Course">
                        <i class="fas fa-edit fs-7"></i>
                      </a>
                      <!-- Delete Button -->
                      <a href="<?php echo e(route('admin.center.destroy', $center->id )); ?>" class="btn btn-danger shadow btn-sm delete-item" title="Delete Course">
                        <i class="fas fa-trash-alt fs-7"></i>
                      </a>
                      </form>
                    </div>

                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>

          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bkvsindia\resources\views/admin/centers/index.blade.php ENDPATH**/ ?>