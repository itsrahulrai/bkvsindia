    <!-- JS here -->
    <script src="{{asset('front-assets/js/vendor/jquery-3.6.0.min.js')}}"></script>
    <script src="{{asset('front-assets/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('front-assets/js/imagesloaded.pkgd.min.js')}}"></script>
    <script src="{{asset('front-assets/js/jquery.magnific-popup.min.js')}}"></script>
    <script src="{{asset('front-assets/js/jquery.odometer.min.js')}}"></script>
    <script src="{{asset('front-assets/js/jquery.appear.js')}}"></script>
    <script src="{{asset('front-assets/js/tween-max.min.js')}}"></script>
    <script src="{{asset('front-assets/js/select2.min.js')}}"></script>
    <script src="{{asset('front-assets/js/swiper-bundle.min.js')}}"></script>
    <script src="{{asset('front-assets/js/jquery.marquee.min.js')}}"></script>
    <script src="{{asset('front-assets/js/tg-cursor.min.js')}}"></script>
    <script src="{{asset('front-assets/js/vivus.min.js')}}"></script>
    <script src="{{asset('front-assets/js/ajax-form.js')}}"></script>
    <script src="{{asset('front-assets/js/svg-inject.min.js')}}"></script>
    <script src="{{asset('front-assets/js/jquery.circleType.js')}}"></script>
    <script src="{{asset('front-assets/js/jquery.lettering.min.js')}}"></script>
    <script src="{{asset('front-assets/js/plyr.min.js')}}"></script>
    <script src="{{asset('front-assets/js/wow.min.js')}}"></script>
    <script src="{{asset('front-assets/js/aos.js')}}"></script>
    <script src="{{asset('front-assets/js/main.js')}}"></script>
    <script src="{{asset('front-assets/js/custom.js')}}"></script>
    <script>
        SVGInject(document.querySelectorAll("img.injectable"));
    </script>
